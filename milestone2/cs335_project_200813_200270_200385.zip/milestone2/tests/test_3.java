public class BubbleSort {
    public static void main() {
        int n = 10, c, d, swap;
        c = 12 + n;
        d = c + 4 + 55;

}
}
