class test_25
{  
    public static void main(int args[])
    {  
	int x = 20;
	int y = 18;
    float z = x + y;
    System.out.println(z);
 
}
}
