public class RANDOM {
    public static void main() {
        int intVar = 100;
        long longVar = intVar;
        int a ;
        a = intVar;
        System.out.println(3.14F);

    }


    public int rohit()
    {
      float xxx = 8.0;
      float x = xxx + 8 - 9*9 -(7/34+8*7);
      System.out.println(x);
    }
}

public class TEST{

    public int vrema()
    {
      int a = 0;
       char c = 'c';
      System.out.println(a+8*9);
    }
       

}