class Main {
  public static void assignOP() {
    
    // Associative and Prcedence

    int a = (((10 % 3) + 2) + (7 / 2 - 3)) - (3 * 4 + 11);

    int d = ((4 * 3) / (2 + 1)) * 4 - (5 > 6);

    int c = (4 + 2 - 7/5 - 2 * 3 + 5) / 1 + 0;

  }

}